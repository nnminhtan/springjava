package Tuan2.NguyenNgocMinhTan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NguyenNgocMinhTanApplication {

	public static void main(String[] args) {
		SpringApplication.run(NguyenNgocMinhTanApplication.class, args);
	}

}
