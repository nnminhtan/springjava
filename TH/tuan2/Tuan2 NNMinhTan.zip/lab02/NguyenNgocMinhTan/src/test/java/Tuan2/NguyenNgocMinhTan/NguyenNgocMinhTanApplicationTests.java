package Tuan2.NguyenNgocMinhTan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NguyenNgocMinhTanApplicationTests {

	@Test
	void contextLoads() {
	}

}
